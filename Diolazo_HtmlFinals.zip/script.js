function toggleDayNight() {
    const body = document.getElementById('mainBackground');
    body.classList.toggle('night-mode');
}
